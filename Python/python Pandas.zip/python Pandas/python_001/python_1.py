import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ====================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# ============   数据库

# url = "https://api.example.com/data"

# response = requests.get(url)
# data = response.json()
# df = pd.DataFrame(data)
# df.to_csv('output.csv', index=False)

# ====================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# ============   技能

# .count()
# .median()
# .value_count() # 用于判断有多少是true 多少是false ， 城市
# .groupby(['Country'])
# country.get_group('China')

# ====================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# ============   通用
# data.shape # 检查有多少行，多少列 数据
# data.location[['China','Japan']] # Filter
# data.location[['China':'Japan']] # Filter China 直到 Japan 中间全部数据也显示
# csv 不要保存 Index
# country[1:3] # 获取 index 1 ~ 2
# country[:10]
# country.set_index('Country', inplace=True) #设定index
# country.sort_index() # index 排序
# country.drop(['X','Z'], axis=0) #删除 x z  axis=1 表示删除指定的列。    axis=0 表示删除指定的行。
# country.reset_index(inplace=True) #还原 数字的index
# filter = (country['Z'] > '1000') & (country['P'] < 10000) # And 条件

# countries = ['China','Japan']
# in_filter = country['Country'].isin(countries) # 是否有在list厘米
# print(country.location[in_filter,['Country', 'Money']]) #获取 有在list里面的数据

# str_filter = country['Country'].str.contains('A')
# print(country.location[~str_filter,'Country'].str.contains('A')) # ~ 反的意思

# str_filter = country['Country'].str.contains('A|Z')
# str_filter = country['Country'].str.contains('[a-m]') # a ~ m

# country.sort_values(by = 'Age', ascending=False) # 排序 年龄  False 是 大到小  True是小到大
# country.sort_values(by = ['Age','Code'], ascending=【False,True】) # 排序 年龄 Code

# country['Age'].sort_values() # 小 到大

# emplyee['sales'].nlargest(10) # 前10最高
# emplyee['sales'].nsmallest(10) # 前10最小

# country.rename(columns = {'Age': 'user age', 'OrgSize': 'Organization Size'}, inplace=True) # 修改列名
# country.columns = country.columns.str.replace('','_') # 将空格变成_

# country.columns = [col.lower() for col in country.columns] # 将所有column 变 小写

# country.loc[country['age'] < 18, ['age_group']] = "young" # 添加新的 列名

# new_user = {
#     'user_age' : 25,
#     'country': 'China',
# }
# country.append(new_user, ignore_index=True,sort=False); # 添加新 数据

# country.drop(columns = ['organization','A'], inplace=True) #删除两个数据

# ====================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# ============   DataFrame
# data_dict = {
#     'name': ['David','Tim','Alice'],
#     'age': [19, 23, 22]
# }
#
# pandas_df = pd.DataFrame(data_dict)
# print(pandas_df)

# ============
# d = {
#     'one' : [1,2,3,4],
#     'two' : [4,3,2,1]
# }
#
# dict_df = pd.DataFrame(d)
# print(dict_df)
# print(dict_df['two'])

# ============
# d = {
#     'one' : pd.Series([1,2,3], name='col_one', index=['a','b','c']),
#     'two' : pd.Series([1,2,3,4], name='col_two', index=['a','b','c','d']),
# }

# ============

# 主

# df = pd.DataFrame(columns = ['age', 'score'])
# df['score'] = np.random.randint(100, size=(10)) # 0~99
# df['age'] = np.random.randint(25, size=(10)) # 0~24

# ============   1
# print(df.head()) # 前 5 行

# ============   2
# df.plot(x='age', y='score', kind='scatter')
# plt.show() # 图案

# ============   3
# sorted_df = df.sort_values(by = ['age'])
# print(sorted_df) # sort

# ============   4
# sort_df = df.sort_values(by='age')
# sort_df.plot(x='age', y='score', kind='line', ax=plt.gca(), label='Sorted DataFrame')
#
# # 添加图例
# plt.legend()
#
# # 显示图表
# plt.show()

# ============   5
# 生成 csv 文件
# sort_df = df.sort_values(by='age')
# sort_df.to_csv('pd_df.csv', index=False)

# ============   6
# 提取 csv 文件
# local_df = pd.read_csv('pd_df.csv')
# print(local_df)

# Link
# data_url = 'https://...'
# local_df = pd.read_csv(data_url)
# print(local_df)

# ============   7
# 清空 / 删除某一个值
# df['age'] = np.nan

# ============   8
# 把空值填 100
# df.fillna(100, inplace=True)

# ============   9
# 找出 max min
# df['age'].max()

# ====================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# ============   Series
# 如果我们只需要一列数据，可以使用 Series 来代替 DataFrame 中的一列：
# 创建两个 Series 对象
# age_series = pd.Series(np.random.randint(25, size=(10)), name='age') # 一列数据
# score_series = pd.Series(np.random.randint(100, size=(10)), name='score') # 一列数据
#
# print(age_series)
# print(score_series)

# ============   1
# 修改 index 名称
# random = np.random.randint(25, size=(10))
# letter_index = ['a','b','c','d','e','f','g','h','i','j']
# new_series = pd.Series(random, index=letter_index)
# print(new_series)

# ============   2
# 修改 index 名称
# data_dict = {'a':1, 'b':2, 'c':3, 'd': 4, 'e':5}
# dict_series = pd.Series(data_dict)
# print(dict_series)

# ============   3
# data_dict = {'a':1, 'b':2, 'c':3, 'd': 4, 'e':5}
# dict_series = pd.Series(data_dict)
# print(dict_series.median()) # 获取中间值
# print(dict_series[dict_series > dict_series.median()]) # 分析大于中间值的数据

# ============   4

# ============   5

# ============   6





































