import matplotlib.pyplot as plt
plt.rc("font",family="Microsoft JhengHei")

# plot 模式
# =======================================

# plt.plot([1,2,3],[2,4,6])
# plt.show()

# =======================================

# plt.plot([2,3,4],[[4,2],[6,3],[8,4]])
# plt.show()

# =======================================

# plt.rc("font",family="Microsoft JhengHei")
# plt.plot(
#     [1,2,3],
#     [[2,1],[4,2],[6,3]],
#     label=["第一组","第二组"]
# )
#
# plt.legend()
# plt.xlabel("X-文字说明")
# plt.ylabel("Y-文字说明")
# plt.show()

# =======================================

# import csv
# file = open("data.csv", encoding = "utf-8")
# reader = csv.reader(file)
# header = next(reader) #读取第一行
# # print("标头",header)
# # 标头 ['年度', '夏娃', '柯美']
#
# x = []
# y = []
# for row in reader:
#     x.append(int(row[0]))
#     y.append([int(row[1]),int(row[2])])
#
# plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体
# plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
# plt.plot(x, y , label=header[1:3])
# plt.legend()
# plt.xlabel(header[0])
# plt.ylabel("薪资")
# plt.show()

# =======================================
# pie 模式
# =======================================

# plt.pie(
#     [10,15,25],
#     labels=["10","15","25"],
#     labeldistance=0.5
# )
# plt.legend()
# plt.show()

# =======================================

# x=[10,15,25]
# total=sum(x)
# labels={str(100*data/total)+"%" for data in x}
# plt.pie(
#     x,
#     labels=labels,
#     labeldistance=0.5
# )
# plt.legend()
# plt.show()

# =======================================

# import csv
# file = open("pie-chat-data.csv", encoding="utf-8")
# reader = csv.reader(file)
# header = next(reader) #读取第一行
#
# x=[]
# labels=[]
# for row in reader:
#     print(row)
#     labels.append(row[0])
#     x.append(int(row[1]))
#
# plt.pie(
#     x,
#     labels=labels,
#     labeldistance=0.5
# )
# plt.legend()
# plt.title("浏览器的占有率发布")
# plt.show()
# file.close()

# =======================================
# scatter 模式
# =======================================

# plt.scatter(
#     [2,3,4],
#     [4,3,6],
#     c="red",
#     s=30
# )
# plt.show()

# =======================================

# import csv
# file = open("scatter-chart-data.csv", encoding="utf-8")
# reader = csv.reader(file)
# header = next(reader) #读取第一行
#
# data={
#     "男":{"x":[], "y":[]},
#     "女":{"x":[], "y":[]}
# }
# for row in reader:
#     gender=row[0]
#     data[gender]["x"].append(int(row[1]))
#     data[gender]["y"].append(int(row[2]))
#
# plt.scatter(data["男"]["x"], data["男"]["y"], label="男生")
# plt.scatter(data["女"]["x"], data["女"]["y"], label="女生")
# plt.legend()
# plt.show()

# =======================================
# bar 模式
# =======================================

# plt.bar([3,4,1],[8,5,2])
# plt.show()

# =======================================

# plt.bar(["B","A","C"],[8,5,2],width=0.5,color="red")
# plt.xlabel("测试X")
# plt.ylabel("测试Y")
# plt.show()

# =======================================

# import csv
# file = open("bar-chart-data.csv", encoding="utf-8")
# reader = csv.reader(file)
# header = next(reader) #读取第一行
#
# x=[]
# height=[]
# for row in reader:
#     x.append(row[0])
#     height.append(int(row[1]))
#
# plt.bar(x,height,width=0.6,color="green")
# plt.xlabel(header[0])
# plt.ylabel(header[1])
# plt.show()

# =======================================











